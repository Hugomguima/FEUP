Trabalho realizado por:
Diogo Samuel Fernandes - up201806250
Hugo Guimar�es - up201806490

OBJETIVOS CUMPRIDOS:
- Ler e guardar a informa��o da ag�ncia, dos clientes e dos pacotes tur�sticos armazenada emficheiros.
- Gerir os clientes e pacotes tur�sticos: criar, alterar e remover um cliente; criar, alterar ou colocar como indispon�vel um pacote tur�stico
- Gerar e visualizar de modo formatado a informa��o de um cliente especificado.
- Gerar e visualizar de modo formatado a informa��o de todos os clientes da ag�ncia.
- Gerar e visualizar de modo formatado os pacotes tur�sticos dispon�veis 
- Gerar e visualizar de modo formatado os pacotes tur�sticos vendidos 
- Efetuar a compra de uma pacote tur�stico por um cliente.
- Calcular e visualizar o n�mero e o valor total de pacotes vendidos.
- Obter o nome dos N locais mais visitados, ordenados por ordem decrescente do n�mero de visitas.
- Gerar uma listagem de todos os clientes na qual se indica, para cada cliente, um dos pacotes em
que seja visitado um dos N locais mais visitados que ele ainda n�o visitou.

OBJETIVOS POR CUMPRIR:
- Todos os objetivos foram cumpridos.

FUNCIONALIDADES IMPLEMENTADAS:
- Um submenu que permite visualizar de modo formatada a informa��o da agencia.

