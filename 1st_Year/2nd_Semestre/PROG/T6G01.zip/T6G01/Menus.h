#pragma once

#include "Agency.h"


unsigned mainMenu(Agency &agency);
int manageClients(Agency &agency);
int managePacks(Agency &agency);
int viewInformation(Agency &agency);
int viewClients(Agency &agency);
int viewPacks(Agency &agency);
int viewSpecificPacks(Agency &agency);
int agencyInformation(Agency &agency);
